var express = require('express');
var router = express.Router();
var passportLinkedIn = require('../auth/linkedin');
var passportGithub = require('../auth/github');
var passportTwitter = require('../auth/twitter');
var passportAmazon = require('../auth/amazon');
var passportAzure = require('../auth/azure');
var passportGoogle = require('../auth/google');
var passportOpenid = require('../auth/openid');
var passportFacebook = require('../auth/facebook');

router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});


//github routes
router.get('/auth/github', passportGithub.authenticate('github', { scope: [ 'user:email' ] }));

router.get('/auth/github/callback',
  passportGithub.authenticate('github', { failureRedirect: '/login' }),
  function(req, res) {
    // Successful authentication
    res.json(req.user);
  });




  //twitter rotues

router.get('/auth/twitter', passportTwitter.authenticate('twitter'));

router.get('/auth/twitter/callback',
  passportTwitter.authenticate('twitter', { failureRedirect: '/login' }),
  function(req, res) {
    // Successful authentication
    res.json(req.user);
  });


//   //linkedin routes
// router.get('/auth/linkedin', passportLinkedIn.authenticate('linkedin'));

// router.get('/auth/linkedin/callback',
//   passportLinkedIn.authenticate('linkedin', { failureRedirect: '/login' }),
//   function(req, res) {
//     // Successful authentication
//     res.json(req.user);
//   });

  //amazon routes 
   
  // GET /auth/amazon
  //   Use passport.authenticate() as route middleware to authenticate the
  //   request.  The first step in Amazon authentication will involve
  //   redirecting the user to amazon.com.  After authorization, Amazon
  //   will redirect the user back to this application at /auth/amazon/callback
//   router.get('/auth/amazon',
//     passportAmazon.authenticate('amazon', { scope: ['profile', 'postal_code'] }),
//     function(req, res){
//       // The request will be redirected to Amazon for authentication, so this
//       // function will not be called.
//     });
  
//   // GET /auth/amazon/callback
//   //   Use passport.authenticate() as route middleware to authenticate the
//   //   request.  If authentication fails, the user will be redirected back to the
//   //   login page.  Otherwise, the primary route function function will be called,
//   //   which, in this example, will redirect the user to the home page.
//   router.get('/auth/amazon/callback', 
//   passportAmazon.authenticate('amazon', { failureRedirect: '/login' }),
//     function(req, res) {
//       res.redirect('/');
//     });
  
//     router.get('/amazon/logout', function(req, res){
//     req.logout();
//     res.redirect('/');
//   });


//   //facebook
//   router.get('/auth/facebook',
//   passportFacebook.authenticate('facebook'));

//   router.get('/auth/facebook/callback',
//   passportFacebook.authenticate('facebook', { failureRedirect: '/login' }),
//   function(req, res) {
//     // Successful authentication, redirect home.
//     res.redirect('/');
//   });


  //openid
//   router.post('/auth/openid',
//   passportOpenid.authenticate('openid'));

//   router.get('/auth/openid/return', 
//   passportOpenid.authenticate('openid', { failureRedirect: '/login' }),
//   function(req, res) {
//     // Successful authentication, redirect home.
//     res.redirect('/');
//   });



  //azure 
//   router.get('/azure/login', 
//   passportAzure.authenticate('azuread-openidconnect', { failureRedirect: '/' }),
//   function(req, res) {
//     log.info('Login was called in the Sample');
//     res.redirect('/');
// });

// // POST /auth/openid/return
// //   Use passport.authenticate() as route middleware to authenticate the
// //   request.  If authentication fails, the user will be redirected back to the
// //   home page.  Otherwise, the primary route function function will be called,
// //   which, in this example, will redirect the user to the home page.
// router.post('/auth/openid/return',
// passportAzure.authenticate('azuread-openidconnect', { failureRedirect: '/' }),
//   function(req, res) { 
//     res.redirect('/');
//   });

//   router.get('/azure/logout', function(req, res){
//   req.logout();
//   res.redirect('/');
// });

// route middleware to make sure a user is logged in
function isLoggedIn(req, res, next) {

	// if user is authenticated in the session, carry on
	if (req.isAuthenticated())
		return next();

	// if they aren't redirect them to the home page
	res.redirect('/');
}


module.exports = router;
