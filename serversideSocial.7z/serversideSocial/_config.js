var ids = {
    github: {
      clientID: '49afeb406340efd9e9ee',
      clientSecret: '76f4584409a055d67ba13028cd4df9bb98f87e21',
      callbackURL: "http://127.0.0.1:3000/auth/github/callback"
    },
    linkedin: {
      clientID: 'get_your_own',
      clientSecret: 'get_your_own',
      callbackURL: "http://127.0.0.1:3000/auth/linkedin/callback"
    },
    twitter: {
        clientID: 'oy3WJA6TsCF7Ti9LCynqzUu0h',
      clientSecret: 'Z6vXgx36ewS8MJIvuPX8V5hqJNJ1H6rpQ390V91kqYMa8HX1HE',
      callbackURL: "https://api.twitter.com/oauth/callback"
    },
    google: {
        clientID: 'get_your_own',
      clientSecret: 'get_your_own',
        callbackURL: "http://127.0.0.1:3000/auth/google/callback"
      },
     amazon: {
        clientID: 'get_your_own',
      clientSecret: 'get_your_own',
        callbackURL: "http://127.0.0.1:3000/auth/amazon/callback"
      },
      openid: {
        clientID: 'get_your_own',
      clientSecret: 'get_your_own',
        callbackURL: "https://www.googleapis.com/oauth2/v4/token"
      },
      facebook: {
        clientID: 'get_your_own',
      clientSecret: 'get_your_own',
        callbackURL: "http://localhost:3000/auth/facebook/callback"
      },
      linkedin: {
        clientID: 'get_your_own',
      clientSecret: 'get_your_own',
        callbackURL: "http://127.0.0.1:3000/auth/linkedin/callback"
      }
  };
  
  module.exports = ids;
  