// //npm install passport-facebook
// var passport = require('passport');
// var FacebookStrategy = require('passport-facebook').Strategy;

// var User = require('./../models/user.model');
// var config = require('../_config');
// var init = require('./init');

// passport.use(new FacebookStrategy({
  
//     clientID: config.facebook.clientID,
//    clientSecret: config.facebook.clientSecret,
//     callbackURL: "http://localhost:3000/auth/facebook/callback"
//   },
//   function(accessToken, refreshToken, profile, cb) {
//     User.findOrCreate({ facebookId: profile.id }, function (err, user) {
//       return cb(err, user);
//     });
//   }
// ));

// // serialize user into the session
// init();


// module.exports = passport;