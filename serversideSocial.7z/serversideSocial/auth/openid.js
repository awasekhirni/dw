// //npm install passport-openid
// var passport = require('passport');
// var util = require('util')
// var OpenIDStrategy = require('passport-openid').Strategy;
//  var User = require('./../models/user.model');
//  var config = require('../_config');
//  var init = require('./init');

// passport.use(new OpenIDStrategy({
//      returnURL: 'http://localhost:3000/auth/openid/return',
//      realm: 'http://localhost:3000/'
//    },
//    function(identifier, done) {
//      User.findByOpenID({ openId: identifier }, function (err, user) {
//        return done(err, user);
//     });
//    }
//  ));


//  //serialize user into the session
//  init();


// module.exports = passport;