// var passport = require('passport');
// var util = require('util')
// var AmazonStrategy = require('passport-amazon').Strategy;

// var User = require('./../models/user.model');
// var config = require('../_config');
// var init = require('./init');


// passport.use(new AmazonStrategy({
//     clientID: config.amazon.clientID,
//    clientSecret: config.amazon.clientSecret,
//     callbackURL: "http://127.0.0.1:3000/auth/amazon/callback"
//   },
//   function(accessToken, refreshToken, profile, done) {
//     User.findOrCreate({ amazonId: profile.id }, function (err, user) {
//       return done(err, user);
//     });
//   }
// ));


// // Passport session setup.
// //   To support persistent login sessions, Passport needs to be able to
// //   serialize users into and deserialize users out of the session.  Typically,
// //   this will be as simple as storing the user ID when serializing, and finding
// //   the user by ID when deserializing.  However, since this example does not
// //   have a database of user records, the complete Amazon profile is
// //   serialized and deserialized.
// passport.serializeUser(function(user, done) {
//     done(null, user);
//   });
  
//   passport.deserializeUser(function(obj, done) {
//     done(null, obj);
//   });

//   // serialize user into the session
// init();


// module.exports = passport;